import numpy as np

# 선형결합 Ax=b의 계수를 구하고 결과를 확인
A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
b = np.array([14, 20, 9], dtype=float)
if abs(np.linalg.det(A)) < 1e-10:
    print("행렬 A가 가역행렬이 아니므로 유일한 계수를 구할 수 없습니다.")
else:
    coeff = np.linalg.solve(A, b)
    print("벡터 b =", b)
    print("선형결합 계수 [c1, c2, c3] =", np.round(coeff, 2))
    print("A @ coeff =", np.round(A @ coeff, 2))
    print("검산 결과가 b와 같으면 선형결합이 성립합니다.")
