import numpy as np
np.set_printoptions(suppress=True, precision=2)

# 수반행렬(여인수 행렬의 전치)을 이용한 역행렬
A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
n = A.shape[0]
det_A = np.linalg.det(A)
if abs(det_A) < 1e-10:
    print("det(A)=0이므로 역행렬이 존재하지 않습니다.")
else:
    cof = np.zeros_like(A)
    for i in range(n):
        for j in range(n):
            minor = np.delete(np.delete(A, i, axis=0), j, axis=1)
            cof[i, j] = ((-1) ** (i + j)) * np.linalg.det(minor)
    adj_A = cof.T
    inv_A = adj_A / det_A
    print("행렬 A:\n", A)
    print("det(A) =", round(det_A, 2))
    print("여인수 행렬:\n", cof)
    print("수반행렬 Adj(A):\n", adj_A)
    print("역행렬 A^(-1):\n", inv_A)
