import numpy as np
np.set_printoptions(suppress=True, precision=2)

# 행렬 A와 단위행렬을 붙여 가우스-조르당 소거법으로 역행렬 계산
A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
I = np.eye(3)
AI = np.hstack((A, I))

def show(title):
    print("\n" + title)
    print(AI)

show("초기 첨가행렬 [A | I]")
AI[1] = AI[1] - 2 * AI[0]
show("R2 <- R2 - 2R1")
AI[2] = AI[2] - AI[0]
show("R3 <- R3 - R1")
AI[2] = AI[2] - 2 * AI[1]
show("R3 <- R3 - 2R2")
AI[2] = AI[2] / AI[2, 2]
show("R3 피벗을 1로")
AI[1] = AI[1] - 3 * AI[2]
AI[0] = AI[0] - 3 * AI[2]
show("위쪽 원소 소거")
AI[0] = AI[0] - 2 * AI[1]
show("R1 <- R1 - 2R2")
print("\nA의 역행렬")
print(AI[:, 3:])
print("\n검산 A @ A^(-1)")
print(A @ AI[:, 3:])
