import numpy as np

# 크래머의 규칙으로 3원 연립방정식 풀이
A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
b = np.array([14, 20, 9], dtype=float)
D = np.linalg.det(A)
if abs(D) < 1e-10:
    print("det(A)=0이므로 유일한 해가 없습니다.")
else:
    values = []
    for j in range(A.shape[1]):
        Aj = A.copy()
        Aj[:, j] = b
        values.append(np.linalg.det(Aj) / D)
        print(f"D{j+1} = {np.linalg.det(Aj):.2f}")
    print("D =", round(D, 2))
    print("해 [x, y, z] =", np.round(values, 2))
    print("검산 Ax =", np.round(A @ values, 2))
