import numpy as np

# 크래머의 규칙으로 2원 연립방정식 풀이
A = np.array([[2, 1], [1, -1]], dtype=float)
b = np.array([5, 1], dtype=float)
D = np.linalg.det(A)
if abs(D) < 1e-10:
    print("det(A)=0이므로 크래머의 규칙으로 유일한 해를 구할 수 없습니다.")
else:
    A1 = A.copy(); A1[:, 0] = b
    A2 = A.copy(); A2[:, 1] = b
    x1 = np.linalg.det(A1) / D
    x2 = np.linalg.det(A2) / D
    print("D =", round(D, 2))
    print("D1 =", round(np.linalg.det(A1), 2))
    print("D2 =", round(np.linalg.det(A2), 2))
    print("해: x1 =", round(x1, 2), ", x2 =", round(x2, 2))
