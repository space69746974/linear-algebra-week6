import numpy as np
np.set_printoptions(suppress=True, precision=2)

A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
print("행렬 A")
print(A)
print("\ndet(A) =", round(np.linalg.det(A), 2))
if abs(np.linalg.det(A)) < 1e-10:
    print("행렬식이 0이므로 역행렬이 존재하지 않습니다.")
else:
    print("\nA의 역행렬")
    print(np.linalg.inv(A))
    print("\nA @ inv(A)")
    print(A @ np.linalg.inv(A))
