import numpy as np
np.set_printoptions(suppress=True, precision=2)

# 역행렬을 이용해 Ax=b의 해를 구한다.
A = np.array([[1, 2, 3], [2, 5, 3], [1, 0, 8]], dtype=float)
b = np.array([13, 15, 9], dtype=float)
print("계수행렬 A:\n", A)
print("상수벡터 b:\n", b)
if abs(np.linalg.det(A)) < 1e-10:
    print("역행렬이 존재하지 않아 이 방법을 사용할 수 없습니다.")
else:
    x = np.linalg.inv(A) @ b
    print("해 x = A^(-1)b:", x)
    print("검산 Ax:", A @ x)
