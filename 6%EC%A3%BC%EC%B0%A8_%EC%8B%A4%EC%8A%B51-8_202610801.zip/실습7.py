import numpy as np

# 두 벡터의 외적과 스칼라 삼중 곱
A = np.array([1, 2, 3], dtype=float)
B = np.array([2, -1, 1], dtype=float)
C = np.array([3, 0, 2], dtype=float)
AxB = np.cross(A, B)
triple = np.dot(AxB, C)
print("A =", A)
print("B =", B)
print("C =", C)
print("A x B =", AxB)
print("(A x B) · C =", triple)
print("행렬식 det([A; B; C]) =", np.linalg.det(np.vstack((A, B, C))))
